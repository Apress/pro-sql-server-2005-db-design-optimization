Sample CLR objects

Unzip ProDatabaseDesignSqlClr.zip file to c:\.

Each sample object is written in both CSharp and VB. 

C:\ProDatabaseDesignSqlClr\CS contains the CSharp versions of each object.
C:\ProDatabaseDesignSqlClr\VB contains the VB versions of each object.

In each folder above, there exists a ProDatabaseDesignSqlClr.sln solution file that can be opened in Visual Studio 2005 Professional Edition and above. 

Each solution file contains the following sample projects:

SPCopyFile    - sample CLR stored proecedure that copies a file on the file system
SpDataAccess  - Sample CLR stored procedure that access data 
TrSsn         - sample CLR trigger that validates a U.S. social security number
TVFFileList   - sample CLR streaming table-valued function that reads files from a folder on the file system
UDAggList     - sample CLR user-defined aggregate that aggregates string values and separates them delimited by commas
UDFGetToken   - sample CLR user-defined function that parses a delimited list and returns text from the specified position
UDFSsn        - sample CLR user-defined function that validates a U.S. social security number
UDFTitleCase  - sample CLR user-defined function that converts a string to title (proper) case
UDTDate       - sample CLR user-defined type that stores a date only without time 
UDTDateClient - sample .NET code to use Date CLR user-defined type in a client application
UDTSsn        - sample CLR user-defined type that stores a U.S. social security number

Projects can be automatically deployed through Visual Studio 2005 Professional Edition or higher by highlighting the project and selecting Build | Deploy. 

Note that the sample database "architectureDatabase" from this book and the Microsoft sample database "AdventureWorks" must be installed for samples to work.

Each language folder contains a "Create CLR objects LANGUAGE.sql" that manually loads assemblies and creates the appropriate SQL Server objects. Use this file if you do not deploy the the objects to SQL Server using Visual Studio 2005.

To test the CLR objects, open up the "c:\ProDatabaseDesignSqlClr\Test CLR objects.sql" file in SQL Server Management Studio and follow the instructions. 

