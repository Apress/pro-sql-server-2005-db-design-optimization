/*
-----------------------------------------------
Run before deploying CLR code using Visual Studio.
If SQLCLR objects manually created, testTriggerCLR has 
already been created
-----------------------------------------------
*/
USE architectureChapter
go

CREATE TABLE dbo.testTriggerCLR
(ssn varchar(11))
go

/*
-----------------------------------------------
Samples in architectureChapter database - must have architectureChapter
database created to run these samples.
-----------------------------------------------
*/

/*
-----------------------------------------------
Create asymmetric keys and logins for accessing
assemblies marked as EXTERNAL_ACCESS
Note that you must change to the correct
-----------------------------------------------
*/
USE master
go  

-- CSharp assembly
CREATE ASYMMETRIC KEY CopyFileKey FROM EXECUTABLE FILE =   
		'C:\ProDatabaseDesignSqlClr\cs\SPCopyFile\bin\SPCopyFile.dll'  

-- VB assembly
CREATE ASYMMETRIC KEY CopyFileKey FROM EXECUTABLE FILE =   
		'C:\ProDatabaseDesignSqlClr\vb\SPCopyFile\bin\SPCopyFile.dll'  

CREATE LOGIN CopyFileLogin FROM ASYMMETRIC KEY CopyFileKey
GRANT EXTERNAL ACCESS ASSEMBLY TO CopyFileLogin
go

-- CSharp assembly
CREATE ASYMMETRIC KEY FileListKey FROM EXECUTABLE FILE =   
		'C:\ProDatabaseDesignSqlClr\cs\TVFFileList\bin\TVFFileList.dll'  

-- VB assembly
CREATE ASYMMETRIC KEY FileListKey FROM EXECUTABLE FILE =   
		'C:\ProDatabaseDesignSqlClr\vb\TVFFileList\bin\TVFFileList.dll'  

CREATE LOGIN FileListLogin FROM ASYMMETRIC KEY FileListKey
GRANT EXTERNAL ACCESS ASSEMBLY TO FileListLogin

USE architectureChapter
go

-- test copy file stored procedure - c:\temp\1.txt must already exist
EXEC dbo.CopyFile 'c:\temp\1.txt', 'c:\temp\2.txt', 1
EXEC dbo.CopyFile 'c:\temp\1.txt', 'c:\temp\3.txt', 1
EXEC dbo.CopyFile 'c:\temp\1.txt', 'c:\temp\4.txt', 1
EXEC dbo.CopyFile 'c:\temp\1.txt', 'c:\temp\5.txt', 1

-- list files in folder with table-valued function
SELECT FileName, FileSize, FileDate
FROM dbo.GetFilesInFolder('c:\temp\', '*.*')
ORDER BY FileSize DESC

-- test Date user-defined datatype
DECLARE @today Date
SET @today = CAST('5/23/2005' AS Date)
SET @today = CAST(CAST(getdate() AS VARCHAR) AS Date)
SET @today = Date::FromSqlDate(getdate())
SET @today = '5/23/2005'
SET @today = Date::Today()
SET @today.Year = 2005
SET @today.Month = 5
SET @today.Day = 23

SELECT @today.ToString()
SELECT Date::Today().ToString()
SELECT Date::FromSqlDate(getdate()).Year
SELECT @today.FormatDate('MMMM dd, yyyy')
SELECT @today.Year

CREATE TABLE dbo.testDate 
(dt Date)
go
INSERT INTO dbo.testDate (dt) 
VALUES ( '05/23/2005')

SELECT dt, dt.ToString(), dt.FormatDate('MMMM yyyy'), dt.Month 
FROM dbo.testDate

-- test social security user-defined datatype
CREATE TABLE dbo.testSsnUDT
(ssn ssn)

-- should get an error since UDT validates social security numbers
INSERT INTO dbo.testSsnUDT (ssn)
VALUES ('000-00-0000')

-- should get inserted since social security number is valid
INSERT INTO dbo.testSsnUDT (ssn)
VALUES ('111-11-1111')

-- should get an error since UDT validates social security numbers
-- and dashes are in the wrong locations
INSERT INTO dbo.testSsnUDT (ssn)
VALUES ('11-111-1111')

-- test CLR trigger
-- should get an error as trigger checks for valid social security number
INSERT INTO dbo.testTriggerCLR (ssn)
VALUES ('000-00-0000')


-- test UDF ssn in trigger
CREATE TABLE dbo.testTriggerTSQL
(ssn varchar(11))
go

CREATE TRIGGER tiu_testTriggerTSQL ON dbo.testTriggerTSQL
FOR INSERT, UPDATE AS
IF UPDATE(ssn)
  IF EXISTS(SELECT 1 FROM inserted WHERE dbo.IsValidSsn(ssn) = 0) 
  BEGIN
    ROLLBACK TRAN
    RAISERROR('Invalid social security number', -1, 16)
  END

-- should get error since trigger uses UDF to 
-- test for valid social security numbers
INSERT INTO dbo.testTriggerTSQL (ssn)
VALUES('000-00-0000')

-- T-SQL GetToken UDF
CREATE FUNCTION dbo.fn_get_token
(
 @string VARCHAR(8000),
 @delimiter VARCHAR(10),
 @tokennum TINYINT
)
RETURNS VARCHAR(8000)
AS
BEGIN
  DECLARE @startpos SMALLINT
  DECLARE @endpos SMALLINT
  DECLARE @tokencount TINYINT
  DECLARE @return VARCHAR(8000)
  DECLARE @delimlength TINYINT

  SET @delimlength = LEN(@delimiter)
  SET @tokencount = 1
  SET @startpos = 1

  WHILE @tokencount <= @tokennum
  BEGIN
    IF @tokencount < @tokennum
    BEGIN
      SET @startpos = CHARINDEX(@delimiter, @string, @startpos)
      IF @startpos > 0 
        SET @startpos = @startpos + @delimlength
      ELSE
        BREAK
    END
    ELSE
    BEGIN
      SET @endpos = CHARINDEX(@delimiter, @string, @startpos)
      IF @endpos = 0
        SET @endpos = LEN(@string) + 1
    END
    SET @tokencount = @tokencount + 1
  END

  IF @startpos = 0 
    SET @return = null
  ELSE
    SET @return = LTRIM(RTRIM(SUBSTRING(@string, @startpos, @endpos - @startpos)))

  RETURN(@return)
END

SELECT dbo.fn_get_token('1,2,3,4', ',', 3)

-- CLR GetToken UDF 
SELECT dbo.GetToken('1,2,3,4', ',', 3)

-- Test TitleCase UDF
SELECT dbo.TitleCase('john doe')

/*
-----------------------------------------------
Samples in AdventureWorks database - must have AdventureWorks sample
database installed to run these samples.
-----------------------------------------------
*/
USE AdventureWorks
go

-- use CLR to access data
EXEC dbo.sales$orderCount 1

-- create T-SQL products by order aggregate
CREATE FUNCTION dbo.products$byOrderTsql(@OrderId int)
RETURNS nvarchar(4000)
AS
BEGIN
    DECLARE @products nvarchar(4000)
    SET @products=NULL

    SELECT @products = ISNULL(@products + ', ', '') + p.Name 
    FROM
        Sales.SalesOrderDetail sod
        JOIN Production.Product p ON sod.ProductID = p.ProductID
    WHERE
        sod.SalesOrderID = @OrderId
    ORDER BY
        p.Name

    RETURN @products
END
go

-- test T-SQL products by order aggregate
SELECT 
    sod.SalesOrderID
  , dbo.products$byOrderTsql(sod.SalesOrderID)
FROM 
  Sales.SalesOrderDetail sod
WHERE
  sod.SalesOrderID BETWEEN 50000 AND 51800 

-- test CLR user-defined aggregate
SELECT 
    sod.SalesOrderID
  , dbo.List(p.Name)
FROM 
  Sales.SalesOrderDetail sod
  JOIN Production.Product p ON sod.ProductID = p.ProductID
WHERE
  sod.SalesOrderID BETWEEN 50000 AND 51800  
GROUP BY 
  sod.SalesOrderID

