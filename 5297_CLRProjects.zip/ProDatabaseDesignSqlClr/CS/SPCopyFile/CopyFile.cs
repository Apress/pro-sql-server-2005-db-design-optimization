using System; 
using System.Data; 
using System.Data.Sql; 
using System.Data.SqlTypes; 
using Microsoft.SqlServer.Server; 
using System.IO; 
using System.Collections;
using System.Diagnostics;

namespace Apress.ProSqlServerDatabaseDesign
{
    public partial class StoredProcedures  
    { 
        // ---------------------------------------
        //  Purpose: SQL Server stored procedure to copy a file
        //  Written: kmw 12/17/2005
        //  Comment: 
        //  
        //  SqlProcedure attribute used only by Visual Studio 
        //  Professional and above. It's not used by SQL Server.
        // ---------------------------------------
        [SqlProcedure(Name="CopyFile")]
        public static void CopyFile(SqlString sourceFile, SqlString destinationFile, SqlBoolean overwrite) 
        { 
            //  check if source file exists
            if (File.Exists(sourceFile.ToString())) 
            { 
                //  if destination file exists, try to delete it 
                //  if overwrite flag is set to true
                if (File.Exists(destinationFile.ToString())) 
                { 
                    if (overwrite) 
                    { 
                        File.Delete(destinationFile.ToString()); 
                    } 
                    else 
                    { 
                        throw new ArgumentException("Destination file already exists."); 
                    } 
                } 
                //  Use .NET class to copy file
                try 
                {
                    File.Copy(sourceFile.ToString(), destinationFile.ToString()); 
                } 
                catch (Exception ex) 
                { 
                    throw new Exception("Could not copy file. " + ex.Message, ex.InnerException); 
                } 
            } 
            else 
            { 
                throw new ArgumentException("Source file does not exist."); 
            } 
        } 
     } 
 } 
