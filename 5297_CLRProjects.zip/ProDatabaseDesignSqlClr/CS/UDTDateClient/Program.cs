using System;
using Apress.ProSqlServerDatabaseDesign;
using System.Data;
using System.Data.SqlClient; 

namespace Apress.ProSqlServerDatabaseDesign
{
    class Program
    {
        public static void Main()
        {
            using (SqlConnection cn = new SqlConnection("server=.;trusted_connection=yes;database=architectureChapter"))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO dbo.testDate (dt) VALUES (@dt)", cn))
                {
                    SqlParameter prm = cmd.Parameters.Add(new SqlParameter("@dt", SqlDbType.Udt));
                    prm.UdtTypeName = "architectureChapter.dbo.Date";
                    prm.Value = new DateUdt(2006, 2, 5);
                    cn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }   
    }
}
