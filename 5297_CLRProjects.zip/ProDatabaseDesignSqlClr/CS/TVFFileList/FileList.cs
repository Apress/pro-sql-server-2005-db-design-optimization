using System; 
using System.Data; 
using System.Data.Sql; 
using System.Data.SqlTypes; 
using Microsoft.SqlServer.Server; 
using System.Collections; 
using System.IO; 

namespace Apress.ProSqlServerDatabaseDesign
{
    public partial class UserDefinedFunctions  
    { 
        // ------------------------------------------------
        //  Purpose: Table-valued function that returns a list of files
        //           in a specified folder with a given file pattern
        //  Written: 12/17/2005
        //  Comment:
        // 
        //  SqlFunction attribute contains data used by SQL Server 2005 
        //  at runtime and by the Professional version of Visual Studio 
        //  and above at deployment time.
        // 
        //  Name - Name of function when created in SQL Server (used by VS at deployment)
        //  FillRowMethodName - Name of method to be called to fill each row (used by SQL Server at runtime)
        //  DataAccess - indicates whether function access SQL Server data (used by SQL Server at runtime)
        //  TableDefinition - Columns of table returned by function (used by VS at deployment)
        // ------------------------------------------------
        [ SqlFunction(DataAccess=DataAccessKind.None, Name="GetFilesInFolder", FillRowMethodName="FillRow", 
                            TableDefinition="FileName nvarchar(255), FileSize int, FileDate datetime") ]
        public static IEnumerable GetFilesInFolder(SqlString path, SqlString pattern) 
        { 
            return (new FileList(path.ToString(), pattern.ToString())); 
        } 
        
        
        //  this is the function pointed to by FillRowMethodName parameter of SqlFunction attribute
        //  parameters must include the IEnumerable object returned by function above (GetFilesInFolder)
        //  followed by each column returned from the function
        public static void FillRow(object obj, ref SqlString FileName, ref SqlInt32 FileSize, ref SqlDateTime FileDate) 
        { 
            FileInfo fi = (FileInfo)obj; 
            FileName = new SqlString(fi.Name); 
            FileSize = new SqlInt32(Convert.ToInt32(fi.Length)); 
            FileDate = new SqlDateTime(fi.CreationTime); 
        } 
    } 
    
    //  --------------------------------
    //  IEnumerable object that will be returned 
    //  to SQL Server as a relational table
    //  Note that FillRowMethodName provides access to the "columns"
    //  --------------------------------
    public class FileList : IEnumerable
    { 
        private string m_path; 
        private string m_pattern; 
        
        public FileList(string path, string pattern) 
        { 
            m_path = path; 
            m_pattern = pattern; 
        }
        
        public IEnumerator GetEnumerator()
        {
            if (Directory.Exists(m_path))
            {
                foreach (string file in Directory.GetFiles(m_path, m_pattern, SearchOption.TopDirectoryOnly))
                {
                    yield return new FileInfo(file);
                }
            }
        }
    } 
} 
