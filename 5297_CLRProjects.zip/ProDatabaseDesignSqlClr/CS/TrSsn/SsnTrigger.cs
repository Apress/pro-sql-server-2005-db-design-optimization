using System; 
using System.Data; 
using System.Data.Sql; 
using System.Data.SqlTypes; 
using System.Data.SqlClient; 
using Microsoft.SqlServer.Server; 
using System.Text.RegularExpressions; 

namespace Apress.ProSqlServerDatabaseDesign
{
    public partial class Triggers  
    { 
        // ------------------------------------------------
        //  Purpose: Trigger that validates SSN column in TestTrigger
        //           table on insert and update
        //  Written: 12/17/2005
        //  Comment:
        // 
        //  SqlTrigger attribute contains data used by SQL Server 2005 
        //  at runtime and by the Professional version of Visual Studio 
        //  and above at deployment time.
        // 
        //  Name - Name of function when created in SQL Server (used by VS at deployment)
        //  Target - Name of table (used by VS at deployment)
        //  Event - Event used to fire trigger (used by VS at deployment)
        // ------------------------------------------------
        [ SqlTrigger(Name="SsnTrigger", Target="testTriggerCLR", Event="FOR UPDATE, INSERT") ]
        public static void SsnTrigger() 
        { 
            //  SqlContext.TriggerContext references SQL Server context that 
            //  provides information on what caused the trigger to fire
            SqlTriggerContext ctx = SqlContext.TriggerContext; 
            switch (ctx.TriggerAction) 
            {
                case TriggerAction.Insert: 
                case TriggerAction.Update:
                    //  context connection=true for connection string indicates we will
                    //  be accessing data from instance of SQL Server that code is
                    //  running from
                    using (SqlConnection conn = new SqlConnection("context connection=true"))
                    {
                        using (SqlCommand cmd = new SqlCommand("SELECT ssn FROM INSERTED", conn))
                        {
                            conn.Open();
                            //  loop through INSERTED table populated with records 
                            //  affected by operation causing the trigger to fire
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                if (dr.HasRows)
                                {
                                    string ssn = null;
                                    while (dr.Read())
                                    {
                                        ssn = dr[0].ToString();
                                        //  validate each Social Security number
                                        if (!IsSsnValid(ssn))
                                        {
                                            throw new Exception("Invalid SSN");
                                        }
                                    }
                                }
                                break;
                            }
                        }
                    }
            }
        } 
        
        private static bool IsSsnValid(string ssn) 
        { 
            //  use Regex matching string to validate Social Security number 
            //  returns True if SSN is valid, False if it is invalid
            return Regex.IsMatch(ssn, @"^(?!000)([0-6]\d{2}|7([0-6]\d|7[012]))([ -]?)(?!00)\d\d\3(?!0000)\d{4}$", RegexOptions.None); 
        } 
    } 
} 
