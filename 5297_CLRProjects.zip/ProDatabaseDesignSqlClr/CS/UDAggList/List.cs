using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Text;

namespace Apress.ProSqlServerDatabaseDesign
{
    //------------------------------------------------
    // Purpose: Aggregates character column as one string separated by commas
    // Written: 12/17/2005
    // Comment:
    //
    // User-defined aggregates must be marked as serializable.
    //
    // SqlUserDefinedAggregate attribute contains data used by SQL Server 2005 
    // at runtime and by the Professional version of Visual Studio 
    // and above at deployment time.
    //
    // Format.UserDefined - we must implement IBinarySerialize ourselves
    // Name - Name of UDAgg when created in SQL Server (used by VS at deployment)
    // MaxByteSize - Maxiumum bytes used for aggregate (used by SQL Server at runtime)
    //------------------------------------------------
    [Serializable()]
    [SqlUserDefinedAggregate(Format.UserDefined, Name = "List", MaxByteSize = 8000)]
    public struct List : IBinarySerialize
    {
        private StringBuilder m_sb;

        // Called when aggregate is initialized by SQL Server
        public void Init()
        {
            m_sb = new StringBuilder();
        }

        // returns string representation of List aggregate
        public override string ToString()
        {
            return m_sb.ToString();
        }

        // Called once for each row being aggregated - can be null
        public void Accumulate(SqlString value)
        {
            // concatenate strings and separate by a comma
            if (!value.IsNull)
            {
                if (m_sb.Length > 0)
                {
                    m_sb.Append(", ");
                }
                m_sb.Append(value.ToString());
            }
        }

        // merge 2 List aggregates togther - used during parallelism
        public void Merge(List value)
        {
            Accumulate(new SqlString(value.ToString()));
        }

        // called when aggregate is finished - return aggregated value
        public SqlString Terminate()
        {
            return (new SqlString(m_sb.ToString()));
        }

        // implement IBinarySerialie.Read since we used Format.UserDefined
        public void Read(System.IO.BinaryReader r)
        {
            m_sb = new StringBuilder(r.ReadString());
        }

        // implement IBinarySerialie.Write since we used Format.UserDefined
        public void Write(System.IO.BinaryWriter w)
        {
            w.Write(m_sb.ToString());
        }
    }
}

