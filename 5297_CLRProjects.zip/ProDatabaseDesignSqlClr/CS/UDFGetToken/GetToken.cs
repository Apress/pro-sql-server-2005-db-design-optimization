using System; 
using System.Data.SqlTypes; 
using Microsoft.SqlServer.Server;

namespace Apress.ProSqlServerDatabaseDesign
{
    public partial class UserDefinedFunctions  
    { 
        // ------------------------------------------------
        //  Purpose: Gets part of delimited string 
        //  Written: 12/17/2005
        //  Comment:
        // 
        //  SqlFunction attribute contains data used by SQL Server 2005 
        //  at runtime and by the Professional version of Visual Studio 
        //  and above at deployment time.
        // 
        //  DataAccess - indicates if function access SQL Server data (used by SQL Server at runtime)
        //  Name - Name of function when created in SQL Server (used by VS at deployment)
        //  IsDeterministic - indicates if function is deterministic
        //  IsPrecise - indicates if function involves imprecise calculations (floating point)
        // ------------------------------------------------
        [ SqlFunction(DataAccess=DataAccessKind.None, Name="GetToken", IsDeterministic=true, IsPrecise=true) ]
        public static SqlString GetToken(SqlString s, SqlString delimiter, SqlByte tokenNumber) 
        { 
            if (s.IsNull) 
            { 
                return SqlString.Null; 
            } 
            //  split string into array at each delimiter
            string[] tokens = s.ToString().Split(delimiter.ToString().ToCharArray()); 
            
            //  return string at array position specified by parameter
            if (tokenNumber.Value > 0 && tokens.Length >= tokenNumber.Value) 
            { 
                return (SqlString)tokens[ tokenNumber.Value - 1 ].Trim(); 
            } 
            return SqlString.Null; 
        } 
    } 
} 
