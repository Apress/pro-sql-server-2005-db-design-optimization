using System; 
using System.Data; 
using System.Data.SqlClient; 
using System.Data.SqlTypes; 
using Microsoft.SqlServer.Server;

namespace Apress.ProSqlServerDatabaseDesign
{
    //------------------------------------------------
    // Purpose: Returns title case of specified string
    // Written: 5/17/2005
    // Comment:
    //
    // SqlFunction attribute contains data used by SQL Server 2005 
    // at runtime and by the Professional version of Visual Studio 
    // and above at deployment time.
    //
    // DataAccess - indicates if function access SQL Server data (used by SQL Server at runtime)
    // Name - Name of function when created in SQL Server (used by VS at deployment)
    // IsDeterministic - indicates if function is deterministic
    // IsPrecise - indicates if function involves imprecise calculations (floating point)
    //------------------------------------------------
    public partial class UserDefinedFunctions  
    { 
        [SqlFunction(IsDeterministic=true, DataAccess=DataAccessKind.None, 
            Name="TitleCase", IsPrecise=true)]
        public static SqlString TitleCase(SqlString inputString) 
        { 
            return new SqlString(System.Threading.Thread.CurrentThread.CurrentCulture.
                TextInfo.ToTitleCase(inputString.ToString().ToLower())); 
        } 
    } 
} 
