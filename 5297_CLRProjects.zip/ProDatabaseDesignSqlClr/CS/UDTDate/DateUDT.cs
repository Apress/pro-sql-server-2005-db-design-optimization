using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

namespace Apress.ProSqlServerDatabaseDesign
{
    // ------------------------------------------------
    // Purpose: Date-only user-defined type 
    // Written: 12/17/2005
    // Comment:
    //
    // SqlUserDefinedType attribute contains data used by SQL Server 2005 
    // at runtime and by the Professional version of Visual Studio 
    // and above at deployment tithis. UDT's must be serializable and implement INullable.
    //
    // Format.Native - indicates SQL server can Serialize the type for us
    // Name - Name of UDT when created in SQL Server (used by VS at deployment)
    // IsByteOrdered - indicates if type can be ordered (used by SQL Server at runtime)
    // IsFixedLength - indicates if length of type is fixed (used by SQL Server at runtime)
    // ------------------------------------------------
    [Serializable()]
    [SqlUserDefinedType(Format.Native, Name = "Date",
                     IsByteOrdered = true, IsFixedLength = true)]
    public struct DateUdt : INullable
    {
        // Private members
        private bool m_Null;
        private int m_year;
        private int m_month;
        private int m_day;

        // overloaded constructor accepting datetime
        public DateUdt(SqlDateTime sqlDate)
        {
            DateTime dt = (DateTime)sqlDate;
            m_year = dt.Year;
            m_month = dt.Month;
            m_day = dt.Day;
            m_Null = false;
        }

        // overloaded constructor accepting year, month, and day as integers
        public DateUdt(SqlInt32 year, SqlInt32 month, SqlInt32 day)
        {
            m_year = (int)year;
            m_month = (int)month;
            m_day = (int)day;
            m_Null = false;
        }

        // overload ToString function
        public override string ToString()
        {
            if (this.IsNull)
            {
                return ("NULL");
            }
            return (this.DateOnly.ToShortDateString());
        }

        // Implement INullable.IsNull
        public bool IsNull
        {
            get { return m_Null; }
        }

        // return our UDT as Null value
        public static DateUdt Null
        {
            get
            {
                DateUdt h = new DateUdt();
                h.m_Null = true;
                return h;
            }
        }

        // accept a string and parse into our UDT
        public static DateUdt Parse(SqlString s)
        {
            if (s.IsNull == true)
            {
                return Null;
            }
            return new DateUdt(DateTime.Parse(s.ToString()));
        }

        // private property to return date only 
        private DateTime DateOnly
        {
            get { return new DateTime(this.Year, this.Month, this.Day); }
        }

        // year property
        public int Year
        {
            get { return m_year; }
            set { m_year = value; }
        }

        // month property
        public int Month
        {
            get { return m_month; }
            set { m_month = value; }
        }

        // day property
        public int Day
        {
            get { return m_day; }
            set { m_day = value; }
        }

        // sets and returns current date only
        public static DateUdt Today()
        {
            return new DateUdt(DateTime.Now);
        }

        // method to pass in a datetime value from SQL Server
        public static DateUdt FromSqlDate(SqlDateTime sqlDate)
        {
            return new DateUdt((DateTime)sqlDate);
        }

        // formats the date with the specified format
        public SqlString FormatDate(SqlString format)
        {
            if (this.IsNull)
            {
                return ("NULL");
            }
            return (new SqlString(this.DateOnly.ToString(format.ToString())));
        }
    }
}
