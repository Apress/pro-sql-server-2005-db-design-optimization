using System; 
using System.Data; 
using System.Data.Sql; 
using System.Data.SqlTypes; 
using Microsoft.SqlServer.Server; 
using System.Data.SqlClient; 

namespace Apress.ProSqlServerDatabaseDesign
{
    public partial class StoredProcedures  
    { 
        // ---------------------------------------
        //  Purpose: SQL Server stored procedure that gets the number
        //           of orders of a specified customer number.
        //  Written: kmw 12/17/2005
        //  Comment: 
        //  
        //  SqlProcedure attribute used only by Visual Studio 
        //  Professional and above. It's not used by SQL Server.
        // ---------------------------------------
        [ SqlProcedure(Name="sales$orderCount") ]
        public static void GetSalesOrderCount(SqlInt32 customerId) 
        { 
            string sql = "SELECT COUNT(*) FROM Sales.SalesOrderHeader " + "WHERE CustomerID = @CustId"; 
            //  context connection=true for connection string indicates we will
            //  be accessing data from instance of SQL Server that code is
            //  running from
            using (SqlConnection cn = new SqlConnection("context connection=true"))
            { 
                using (SqlCommand cmd = new SqlCommand(sql, cn))
                { 
                    SqlParameter prmCustId = cmd.Parameters.Add(new SqlParameter("@CustId", SqlDbType.Int, 4)); 
                    prmCustId.Value = customerId.Value; 
                    cn.Open(); 
                    //  SqlContext is context that code is running in on
                    //  SQL Server. Pipe is a class used to send data 
                    //  to client.
                    SqlContext.Pipe.ExecuteAndSend(cmd); 
                } 
            } 
        } 
    } 
} 
