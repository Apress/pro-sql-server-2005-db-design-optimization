Option Strict On
Option Explicit On

Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server
Imports System.Text.RegularExpressions

Partial Public Class UserDefinedFunctions
    '------------------------------------------------
    ' Purpose: Determines if Social Security number is valid
    ' Written: 12/17/2005
    ' Comment:
    '
    ' SqlFunction attribute contains data used by SQL Server 2005 
    ' at runtime and by the Professional version of Visual Studio 
    ' and above at deployment time.
    '
    ' DataAccess - indicates if function access SQL Server data (used by SQL Server at runtime)
    ' Name - Name of function when created in SQL Server (used by VS at deployment)
    ' IsDeterministic - indicates if function is deterministic
    ' IsPrecise - indicates if function involves imprecise calculations (floating point)
    '------------------------------------------------
    <Microsoft.SqlServer.Server.SqlFunction(DataAccess:=DataAccessKind.None, _
                Name:="IsValidSsn", IsDeterministic:=True, IsPrecise:=True)> _
    Public Shared Function IsValidSsn(ByVal ssn As SqlString) As SqlBoolean
        ' use RegEx matching to validate SSN - returns true if valid, false if not
        Return New SqlBoolean(Regex.IsMatch(ssn.ToString(), _
            "^(?!000)([0-6]\d{2}|7([0-6]\d|7[012]))([ -]?)(?!00)\d\d\3(?!0000)\d{4}$", _
            RegexOptions.None))
    End Function
End Class
