Option Strict On
Option Explicit On

Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server
Imports System.Collections
Imports System.IO

Partial Public Class UserDefinedFunctions
    '------------------------------------------------
    ' Purpose: Table-valued function that returns a list of files
    '          in a specified folder with a given file pattern
    ' Written: 12/17/2005
    ' Comment:
    '
    ' SqlFunction attribute contains data used by SQL Server 2005 
    ' at runtime and by the Professional version of Visual Studio 
    ' and above at deployment time.
    '
    ' Name - Name of function when created in SQL Server (used by VS at deployment)
    ' FillRowMethodName - Name of method to be called to fill each row (used by SQL Server at runtime)
    ' DataAccess - indicates whether function access SQL Server data (used by SQL Server at runtime)
    ' TableDefinition - Columns of table returned by function (used by VS at deployment)
    '------------------------------------------------
    <SqlFunction(DataAccess:=DataAccessKind.None, Name:="GetFilesInFolder", FillRowMethodName:="FillRow", _
        TableDefinition:="FileName nvarchar(255), FileSize int, FileDate datetime")> _
    Public Shared Function GetFilesInFolder(ByVal path As SqlString, ByVal pattern As SqlString) As IEnumerable
        Return (New FileList(path.ToString(), pattern.ToString()))
    End Function

    ' this is the function pointed to by FillRowMethodName parameter of SqlFunction attribute
    ' parameters must include the IEnumerable object returned by function above (GetFilesInFolder)
    ' followed by each column returned from the function
    Public Shared Sub FillRow(ByVal obj As Object, ByRef FileName As SqlString, ByRef FileSize As SqlInt32, ByRef FileDate As SqlDateTime)
        Dim fi As FileInfo = CType(obj, FileInfo)
        FileName = New SqlString(fi.Name)
        FileSize = New SqlInt32(Convert.ToInt32(fi.Length))
        FileDate = New SqlDateTime(fi.CreationTime)
    End Sub
End Class

' --------------------------------
' IEnumerable object that will be returned 
' to SQL Server as a relational table
' Note that FillRowMethodName provides access to the "columns"
' --------------------------------
Public Class FileList
    Implements IEnumerable

    Private m_path As String
    Private m_pattern As String

    Public Function GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return New FileListEnumerator(m_path, m_pattern)
    End Function

    Public Sub New(ByVal path As String, ByVal pattern As String)
        m_path = path
        m_pattern = pattern
    End Sub

    Partial Private Class FileListEnumerator
        Implements IEnumerator

        Dim m_files As String() ' holds list of files in folder
        Dim m_fileNumber As Integer = -1

        ' constructor that includes folder path and any file search pattern
        Public Sub New(ByVal path As String, ByVal pattern As String)
            Try
                ' try to get top level files in specified folder using pattern if supplied
                m_files = Directory.GetFiles(path, pattern, SearchOption.TopDirectoryOnly)
            Catch
                m_files = Nothing
            End Try
        End Sub

        ' must be implemented according to IEnumerator interface - returns current file information
        ' for current array number we are on while SQL Server is looping through collection
        Public ReadOnly Property Current() As Object Implements System.Collections.IEnumerator.Current
            Get
                Return New FileInfo(m_files(m_fileNumber))
            End Get
        End Property

        ' must be implemented according to IEnumerator interface - moves to next array number of files 
        Public Function MoveNext() As Boolean Implements System.Collections.IEnumerator.MoveNext
            m_fileNumber += 1
            If m_files Is Nothing OrElse m_fileNumber > m_files.Length - 1 Then
                Return False
            Else
                Return True
            End If
        End Function

        ' must be implemented according to IEnumerator interface - resets array number
        Public Sub Reset() Implements System.Collections.IEnumerator.Reset
            m_fileNumber = -1
        End Sub
    End Class

End Class



