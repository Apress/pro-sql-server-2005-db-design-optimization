Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports System.Data.sqlclient
Imports Microsoft.SqlServer.Server
Imports System.Text.RegularExpressions

Partial Public Class Triggers
    '------------------------------------------------
    ' Purpose: Trigger that validates SSN column in TestTrigger
    '          table on insert and update
    ' Written: 12/17/2005
    ' Comment:
    '
    ' SqlTrigger attribute contains data used by SQL Server 2005 
    ' at runtime and by the Professional version of Visual Studio 
    ' and above at deployment time.
    '
    ' Name - Name of function when created in SQL Server (used by VS at deployment)
    ' Target - Name of table (used by VS at deployment)
    ' Event - Event used to fire trigger (used by VS at deployment)
    '------------------------------------------------
    <SqlTrigger(Name:="SsnTrigger", _
                        Target:="testTriggerCLR", Event:="FOR UPDATE, INSERT")> _
    Public Shared Sub SsnTrigger()
        ' SqlContext.TriggerContext references SQL Server context that 
        ' provides information on what caused the trigger to fire
        Dim ctx As SqlTriggerContext = SqlContext.TriggerContext
        Select Case ctx.TriggerAction
            Case TriggerAction.Insert, TriggerAction.Update
                ' context connection=true for connection string indicates we will
                ' be accessing data from instance of SQL Server that code is
                ' running from
                Using conn As SqlConnection = New SqlConnection("context connection=true")
                    Using cmd As SqlCommand = New SqlCommand("SELECT ssn FROM INSERTED", conn)
                        conn.Open()
                        ' loop through INSERTED table populated with records 
                        ' affected by operation causing the trigger to fire
                        Using dr As SqlDataReader = cmd.ExecuteReader()
                            If dr.HasRows Then
                                Dim ssn As String
                                Do While dr.Read()
                                    ssn = dr(0).ToString()
                                    ' validate each Social Security number
                                    If Not IsSsnValid(ssn) Then
                                        Throw New Exception("Invalid SSN")
                                    End If
                                Loop
                            End If
                        End Using
                    End Using
                End Using
        End Select
    End Sub

    Private Shared Function IsSsnValid(ByVal ssn As String) As Boolean
        ' use Regex matching string to validate Social Security number 
        ' returns True if SSN is valid, False if it is invalid
        Return Regex.IsMatch(ssn, _
            "^(?!000)([0-6]\d{2}|7([0-6]\d|7[012]))([ -]?)(?!00)\d\d\3(?!0000)\d{4}$", _
            RegexOptions.None)
    End Function
End Class
