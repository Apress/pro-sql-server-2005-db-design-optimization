Option Strict On

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server

Partial Public Class UserDefinedFunctions
    '------------------------------------------------
    ' Purpose: Returns title case of specified string
    ' Written: 5/17/2005
    ' Comment:
    '
    ' SqlFunction attribute contains data used by SQL Server 2005 
    ' at runtime and by the Professional version of Visual Studio 
    ' and above at deployment time.
    '
    ' DataAccess - indicates if function access SQL Server data (used by SQL Server at runtime)
    ' Name - Name of function when created in SQL Server (used by VS at deployment)
    ' IsDeterministic - indicates if function is deterministic
    ' IsPrecise - indicates if function involves imprecise calculations (floating point)
    '------------------------------------------------
    <SqlFunction(IsDeterministic:=True, DataAccess:=DataAccessKind.None, _
                    Name:="TitleCase", IsPrecise:=True)> _
    Public Shared Function TitleCase(ByVal inputString As SqlString) As SqlString
        Return New SqlString(System.Threading.Thread.CurrentThread.CurrentCulture. _
            TextInfo.ToTitleCase(inputString.ToString().ToLower()))
    End Function
End Class
