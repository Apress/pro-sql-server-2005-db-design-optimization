Option Strict On
Option Explicit On

Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server
Imports System.IO

Partial Public Class StoredProcedures
    '---------------------------------------
    ' Purpose: SQL Server stored procedure to copy a file
    ' Written: kmw 12/17/2005
    ' Comment: 
    ' 
    ' SqlProcedure attribute used only by Visual Studio 
    ' Professional and above. It's not used by SQL Server.
    '---------------------------------------
    <SqlProcedure(Name:="CopyFile")> _
    Public Shared Sub CopyFile(ByVal sourceFile As SqlString, _
                               ByVal destinationFile As SqlString, _
                               ByVal overwrite As SqlBoolean)
        ' check if source file exists
        If File.Exists(sourceFile.ToString()) Then
            ' if destination file exists, try to delete it 
            ' if overwrite flag is set to true
            If File.Exists(destinationFile.ToString()) Then
                If overwrite = True Then
                    File.Delete(destinationFile.ToString())
                Else
                    Throw New ArgumentException("Destination file already exists.")
                End If
            End If
            ' Use .NET class to copy file
            Try
                File.Copy(sourceFile.ToString(), destinationFile.ToString())
            Catch ex As Exception
                Throw New Exception("Could not copy file. " & ex.Message, ex.InnerException)
            End Try
        Else
            Throw New ArgumentException("Source file does not exist.")
        End If
    End Sub
End Class
