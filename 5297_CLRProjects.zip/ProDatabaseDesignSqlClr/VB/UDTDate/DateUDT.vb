Option Strict On
Option Explicit On

Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server

'------------------------------------------------
' Purpose: Date-only user-defined type 
' Written: 12/17/2005
' Comment:
'
' SqlUserDefinedType attribute contains data used by SQL Server 2005 
' at runtime and by the Professional version of Visual Studio 
' and above at deployment time. UDT's must be serializable and implement INullable.
'
' Format.Native - indicates SQL server can Serialize the type for us
' Name - Name of UDT when created in SQL Server (used by VS at deployment)
' IsByteOrdered - indicates if type can be ordered (used by SQL Server at runtime)
' IsFixedLength - indicates if length of type is fixed (used by SQL Server at runtime)
'------------------------------------------------
<Serializable()> _
<SqlUserDefinedType(Format.Native, Name:="Date", _
                 IsByteOrdered:=True, IsFixedLength:=True)> _
Public Structure DateUdt
    Implements INullable

    ' Private members
    Private m_Null As Boolean
    Private m_year As Integer
    Private m_month As Integer
    Private m_day As Integer

    ' overloaded constructor accepting datetime
    Public Sub New(ByVal sqlDate As SqlDateTime)
        Dim dt As DateTime = CType(sqlDate, DateTime)
        Me.Year = dt.Year
        Me.Month = dt.Month
        Me.Day = dt.Day
    End Sub

    ' overloaded constructor accepting year, month, and day as integers
    Public Sub New(ByVal year As SqlInt32, ByVal month As SqlInt32, ByVal day As SqlInt32)
        Me.Year = CType(year, Integer)
        Me.Month = CType(month, Integer)
        Me.Day = CType(day, Integer)
    End Sub

    ' overload ToString function
    Public Overrides Function ToString() As String
        If Me.IsNull Then
            Return "NULL"
        End If
        Return Me.DateOnly.ToShortDateString()
    End Function

    ' Implement INullable.IsNull
    Public ReadOnly Property IsNull() As Boolean Implements INullable.IsNull
        Get
            Return m_Null
        End Get
    End Property

    ' return our UDT as Null value
    Public Shared ReadOnly Property Null() As DateUdt
        Get
            Dim h As DateUdt = New DateUdt
            h.m_Null = True
            Return h
        End Get
    End Property

    ' accept a string and parse into our UDT
    Public Shared Function Parse(ByVal s As SqlString) As DateUdt
        If s.IsNull Then
            Return Null
        End If
        Return New DateUdt(DateTime.Parse(s.ToString))
    End Function

    ' private property to return date only 
    Private ReadOnly Property DateOnly() As Date
        Get
            Return DateSerial(Me.Year, Me.Month, Me.Day)
        End Get
    End Property

    ' year property
    Public Property Year() As Integer
        Get
            Return m_year
        End Get

        Set(ByVal value As Integer)
            m_year = value
        End Set
    End Property

    ' month property
    Public Property Month() As Integer
        Get
            Return m_month
        End Get

        Set(ByVal value As Integer)
            m_month = value
        End Set
    End Property

    ' day property
    Public Property Day() As Integer
        Get
            Return m_day
        End Get

        Set(ByVal value As Integer)
            m_day = value
        End Set
    End Property

    ' sets and returns current date only
    Public Shared Function Today() As DateUdt
        Return New DateUdt(DateTime.Now())
    End Function

    ' method to pass in a datetime value from SQL Server
    Public Shared Function FromSqlDate(ByVal sqlDate As SqlDateTime) As DateUdt
        Return New DateUdt(CType(sqlDate, DateTime))
    End Function

    ' formats the date with the specified format
    Public Function FormatDate(ByVal format As SqlString) As SqlString
        If Me.IsNull Then
            Return "NULL"
        End If
        Return New SqlString(Me.DateOnly.ToString(format.ToString()))
    End Function

End Structure

