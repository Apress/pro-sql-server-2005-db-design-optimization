Option Strict On

Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server
Imports System.Text.RegularExpressions

'------------------------------------------------
' Purpose: Social Security number user-defined type 
' Written: 12/17/2005
' Comment:
'
' SqlUserDefinedType attribute contains data used by SQL Server 2005 
' at runtime and by the Professional version of Visual Studio 
' and above at deployment time. UDT's must be serializable and implement INullable.
'
' Format.Native - indicates SQL server can Serialize the type for us
' Name - Name of UDT when created in SQL Server (used by VS at deployment)
' IsByteOrdered - indicates if type can be ordered (used by SQL Server at runtime)
' IsFixedLength - indicates if length of type is fixed (used by SQL Server at runtime)
'------------------------------------------------
<Serializable()> _
<Microsoft.SqlServer.Server.SqlUserDefinedType(Format.Native, Name:="SSN")> _
Public Structure SsnUdt
    Implements INullable

    ' Private member
    Private m_Null As Boolean
    Private m_ssn As Integer

    Public Overrides Function ToString() As String
        ' format SSN for output
        Return Me.Ssn.ToString("000-00-0000")
    End Function

    ' private property to set/get ssn stored as intger
    Private Property Ssn() As Integer
        Get
            Return m_ssn
        End Get
        Set(ByVal value As Integer)
            m_ssn = value
        End Set
    End Property

    Public ReadOnly Property IsNull() As Boolean Implements INullable.IsNull
        Get
            Return m_Null
        End Get
    End Property

    ' return our UDT as a null value
    Public Shared ReadOnly Property Null() As SsnUDT
        Get
            Dim h As SsnUDT = New SsnUDT
            h.m_Null = True
            Return h
        End Get
    End Property

    ' get data from SQL Server as string and parse to return our UDT
    Public Shared Function Parse(ByVal s As SqlString) As SsnUDT
        If s.IsNull Then
            Return Null
        End If

        ' validate value being passed in as a valid SSN
        If IsSsnValid(s.ToString()) Then
            Dim u As SsnUDT = New SsnUDT
            u.Ssn = ConvertSSNToInt(s.ToString())
            Return u
        Else
            Throw New ArgumentException("SSN is not valid.")
        End If
    End Function

    ' validate ssn using regex matching - returns true if valid, false if not
    Private Shared Function IsSsnValid(ByVal ssn As String) As Boolean
        Return Regex.IsMatch(ssn, _
                "^(?!000)([0-6]\d{2}|7([0-6]\d|7[012]))([ -]?)(?!00)\d\d\3(?!0000)\d{4}$", _
                RegexOptions.None)
    End Function

    ' private function to convert SSN as a string to an integer
    Private Shared Function ConvertSSNToInt(ByVal ssn As String) As Integer
        Dim ssnNumbers As Integer
        Try
            ' try a simple conversion
            ssnNumbers = Convert.ToInt32(ssn)
        Catch ex As Exception
            ' if simple conversion fails, strip out everything
            ' but numbers and convert to integer
            Dim ssnString As String = ""
            For i As Integer = 0 To ssn.Length - 1
                If "0123456789".IndexOf(ssn.Chars(i)) >= 0 Then
                    ssnString += ssn.Chars(i)
                End If
            Next
            ssnNumbers = Convert.ToInt32(ssnString)
        End Try
        Return ssnNumbers
    End Function

End Structure

