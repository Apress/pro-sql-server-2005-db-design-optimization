Option Explicit On

Imports Apress.ProSqlServerDatabaseDesign
Imports System.Data.SqlClient

Module Module1
    Sub Main()
        Using cn As New SqlConnection("server=.;trusted_connection=yes;database=architectureChapter")
            Using cmd As New SqlCommand("INSERT INTO dbo.testDate (dt) VALUES (@dt)", cn)
                Dim prm As SqlParameter = cmd.Parameters.Add(New SqlParameter("@dt", SqlDbType.Udt))
                prm.UdtTypeName = "architectureChapter.dbo.Date"
                prm.Value = New DateUDT(2006, 2, 5)
                cn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub
End Module
