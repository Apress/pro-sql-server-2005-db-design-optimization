Option Strict On
Option Explicit On

Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server
Imports System.Data.SqlClient

Partial Public Class StoredProcedures
    '---------------------------------------
    ' Purpose: SQL Server stored procedure that gets the number
    '          of orders of a specified customer number.
    ' Written: kmw 12/17/2005
    ' Comment: 
    ' 
    ' SqlProcedure attribute used only by Visual Studio 
    ' Professional and above. It's not used by SQL Server.
    '---------------------------------------
    <SqlProcedure(Name:="sales$orderCount")> _
    Public Shared Sub GetSalesOrderCount(ByVal customerId As SqlInt32)
        Dim sql As String = "SELECT COUNT(*) FROM Sales.SalesOrderHeader " _
                                & "WHERE CustomerID = @CustId"
        ' context connection=true for connection string indicates we will
        ' be accessing data from instance of SQL Server that code is
        ' running from
        Using cn As New SqlConnection("context connection=true")
            Using cmd As New SqlCommand(sql, cn)
                Dim prmCustId As SqlParameter = cmd.Parameters.Add _
                            (New SqlParameter("@CustId", SqlDbType.Int, 4))
                prmCustId.Value = customerId.Value
                cn.Open()
                ' SqlContext is context that code is running in on
                ' SQL Server. Pipe is a class used to send data 
                ' to client.
                SqlContext.Pipe.ExecuteAndSend(cmd)
            End Using
        End Using
    End Sub
End Class
