Option Strict On
Option Explicit On

Imports System
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server

Partial Public Class UserDefinedFunctions
    '------------------------------------------------
    ' Purpose: Gets part of delimited string 
    ' Written: 12/17/2005
    ' Comment:
    '
    ' SqlFunction attribute contains data used by SQL Server 2005 
    ' at runtime and by the Professional version of Visual Studio 
    ' and above at deployment time.
    '
    ' DataAccess - indicates if function access SQL Server data (used by SQL Server at runtime)
    ' Name - Name of function when created in SQL Server (used by VS at deployment)
    ' IsDeterministic - indicates if function is deterministic
    ' IsPrecise - indicates if function involves imprecise calculations (floating point)
    '------------------------------------------------
    <SqlFunction(DataAccess:=DataAccessKind.None, Name:="GetToken", _
                    IsDeterministic:=True, IsPrecise:=True)> _
    Public Shared Function GetToken(ByVal s As SqlString, _
                        ByVal delimiter As SqlString, _
                        ByVal tokenNumber As SqlByte) As SqlString
        If s.IsNull() Then
            Return SqlString.Null
        End If
        ' split string into array at each delimiter
        Dim tokens() As String = Strings.Split _
            (s.ToString(), delimiter.ToString(), -1, CompareMethod.Text)

        ' return string at array position specified by parameter
        If tokenNumber.Value > 0 AndAlso tokens.Length >= tokenNumber.Value Then
            Return tokens(tokenNumber.Value - 1).Trim()
        Else
            Return SqlString.Null
        End If
    End Function
End Class
